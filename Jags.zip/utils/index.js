export { default as outer } from './outer';
export { default as mySelf } from './mySelf';
export { default as works } from './works';
export { default as projects } from './projects';
export { default as reviews } from './reviews';
export { default as graphics } from './graphics';
// export { default as mapsContribution } from './mapsContribution';
export { default as contact } from './contact';
export { default as header } from './header';