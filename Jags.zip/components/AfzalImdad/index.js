import React from "react";


export default function AfzalImdad() {
  return (
    <div className="fullscreen-container">
      <h1 className="title">Bala Murugan</h1>
    </div>
  );
}
