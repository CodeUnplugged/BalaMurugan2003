import React from 'react'

const K1 = props => {
  return (
    <svg {...props} version="1.2" fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000" width="1000" height="1000">
    <title>K1</title>
    {/* <style>
      .s0 { fill: #000000 } 
      .s1 { fill: none } 
    </style> */}
    <g id="Folder 1" fill="inherit">
		<path id="Shape 4" className="s0" d="m527 307l48-62-8 50-3 22-7 31-35 184-14 80v67 34l-12-40 5-115z"/>
    </g>
    <path id="Layer 2" fill="none" className="s1" d="m0 0h1000v1000h-1000z"/>
  </svg>
  )
}

K1.propTypes = {}

export default K1